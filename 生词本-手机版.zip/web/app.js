/* 英语生词本 Web APP - 纯前端实现（SM-2 简化变体，与 Python 版算法一致） */
(function () {
  "use strict";

  // 兜底剥离行首全大写英文 POS 代码（N-COUNT / PHR-MODAL / VERB 等）
  var POS_STRIP = /^[A-Z][A-Z-]{1,14}\s+/;

  function stripPosLines(trans) {
    return (trans || "").split("\n").map(function (l) {
      return l.replace(POS_STRIP, "").trim();
    }).filter(function (l) { return l; }).join("\n");
  }

  // ==================== 存储层 ====================
  var KEY = "vocab-web-v1";

  function loadState() {
    var raw = null;
    try { raw = localStorage.getItem(KEY); } catch (e) {}
    if (raw) {
      try {
        var s = JSON.parse(raw);
        s.settings = s.settings || {};
        s.settings.newQuota = s.settings.newQuota || 20;
        s.settings.dayBoundary = s.settings.dayBoundary === undefined ? 4 : s.settings.dayBoundary;
        s.settings.articleThreshold = s.settings.articleThreshold || 10;
        s.settings.readLevel = s.settings.readLevel || "cet6";
        s.articles = s.articles || [];
        return s;
      } catch (e) {}
    }
    // 首次运行：迁移 Python 版导出的生词本
    var notebook = {};
    var arr = (window.NOTEBOOK || []);
    arr.forEach(function (r) {
      var roots = r.roots;
      var conf = r.confusables;
      if (typeof roots === "string") {
        try { roots = JSON.parse(roots); } catch (e) { roots = []; }
      } else if (!Array.isArray(roots)) roots = [];
      if (typeof conf === "string") {
        try { conf = JSON.parse(conf); } catch (e) { conf = []; }
      } else if (!Array.isArray(conf)) conf = [];
      notebook[r.word] = {
        word: r.word,
        phonetic: r.phonetic || "",
        translation: stripPosLines(r.translation),  // 剥离旧柯林斯 POS 代码
        example: r.example || "",
        roots: roots,
        confusables: conf,
        status: r.status || "NEW",
        repetition: r.repetition || 0,
        interval_days: r.interval_days || 0,
        ef: r.ef || 2.5,
        next_review: r.next_review || "",
        added_at: r.added_at || "",
        last_reviewed: r.last_reviewed || "",
        total_reviews: r.total_reviews || 0,
        fuzzy_count: r.fuzzy_count || 0
      };
    });
    return { notebook: notebook, log: [], articles: [],
             settings: { newQuota: 20, dayBoundary: 4, articleThreshold: 10, readLevel: "cet6" } };
  }

  var state = loadState();

  function save() {
    try { localStorage.setItem(KEY, JSON.stringify(state)); } catch (e) {}
  }

  // ==================== 工具 ====================
  function pad(n) { return n < 10 ? "0" + n : "" + n; }

  function todayStr(now) {
    now = now || new Date();
    var d = new Date(now);
    if (d.getHours() < state.settings.dayBoundary) d.setDate(d.getDate() - 1);
    return d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate());
  }

  function addDays(dateStr, days) {
    var parts = dateStr.split("-");
    var d = new Date(+parts[0], +parts[1] - 1, +parts[2] + days);
    return d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate());
  }

  function firstLine(t) { t = t || ""; var i = t.indexOf("\n"); return i >= 0 ? t.slice(0, i) : t; }

  function esc(s) {
    return (s || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  }

  function $(sel) { return document.querySelector(sel); }
  function $$(sel) { return Array.prototype.slice.call(document.querySelectorAll(sel)); }

  // ==================== 记忆算法（SM-2 简化变体，与 scheduler.py 一致） ====================
  var EF_MIN = 1.3, EF_MAX = 2.8, INTERVAL_MAX = 180, MASTERY = 21;

  function gradeWord(row, grade, today) {
    var rep = row.repetition, interval = row.interval_days,
        ef = row.ef || 2.5, status = row.status || "NEW", fuzzyDelta = 0;
    if (grade === "know") {
      rep += 1;
      if (rep === 1) interval = 1;
      else if (rep === 2) interval = 3;
      else interval = Math.round(interval * ef);
      ef = Math.min(EF_MAX, ef + 0.05);
    } else if (grade === "fuzzy") {
      interval = interval > 0 ? Math.max(1, Math.round(interval * 0.5)) : 1;
      ef = Math.max(EF_MIN, ef - 0.15);
      fuzzyDelta = 1;
    } else if (grade === "unknown") {
      rep = 0; interval = 0;
      ef = Math.max(EF_MIN, ef - 0.20);
    }
    interval = Math.min(INTERVAL_MAX, interval);
    if (status === "NEW") status = "LEARNING";
    if (grade === "know") {
      if (status === "LEARNING" && rep >= 2) status = "REVIEWING";
      if (interval >= MASTERY) status = "MASTERED";
    } else if (grade === "unknown" && status === "MASTERED") {
      status = "REVIEWING";
    }
    var next = grade === "unknown" ? addDays(today, 1) : addDays(today, interval);
    return {
      status: status, repetition: rep, interval_days: interval,
      ef: Math.round(ef * 100) / 100, next_review: next, fuzzyDelta: fuzzyDelta
    };
  }

  function applyGrade(word, grade, today) {
    var row = state.notebook[word];
    if (!row) return null;
    var upd = gradeWord(row, grade, today);
    row.status = upd.status; row.repetition = upd.repetition;
    row.interval_days = upd.interval_days; row.ef = upd.ef;
    row.next_review = upd.next_review;
    row.last_reviewed = new Date().toISOString().slice(0, 19).replace("T", " ");
    row.total_reviews += 1;
    row.fuzzy_count += upd.fuzzyDelta;
    state.log.push({ word: word, at: new Date().toISOString(), grade: grade,
                     interval: upd.interval_days });
    if (state.log.length > 20000) state.log.splice(0, state.log.length - 20000);
    save();
    return upd;
  }

  // ==================== 学习会话（主队列 + 复现队列） ====================
  function buildDailyQueue() {
    var today = todayStr();
    var due = [], nw = [];
    Object.keys(state.notebook).forEach(function (w) {
      var r = state.notebook[w];
      if (r.status === "MASTERED") return;
      if (r.next_review && r.next_review <= today) due.push(r);
      else if (r.status === "NEW") nw.push(r);
    });
    due.sort(function (a, b) { return a.next_review < b.next_review ? -1 : 1; });
    return due.concat(nw.slice(0, state.settings.newQuota));
  }

  function Session() {
    this.main = buildDailyQueue();
    this.pending = {};       // word -> {row, dueAt}
    this.requeueCount = {};
    this.served = 0;
    this.current = null;
    this.results = { know: 0, fuzzy: 0, unknown: 0 };
    this.servedWords = [];   // 本次会话出过的词（拼写巩固题库）
    this.total = this.main.length + Object.keys(this.pending).length;
  }
  Session.prototype.nextWord = function () {
    var self = this;
    for (var w in this.pending) {
      if (this.served >= this.pending[w].dueAt) {
        var it = this.pending[w]; delete this.pending[w];
        this.current = it.row; this.servedWords.push(it.row.word);
        return this.current;
      }
    }
    if (this.main.length) {
      this.current = this.main.shift(); this.served += 1;
      this.servedWords.push(this.current.word);
      return this.current;
    }
    for (var w2 in this.pending) {
      var it2 = this.pending[w2]; delete this.pending[w2];
      this.current = it2.row; this.servedWords.push(it2.row.word);
      return this.current;
    }
    this.current = null; return null;
  };
  Session.prototype.submitGrade = function (grade) {
    if (!this.current) return false;
    this.results[grade] += 1;
    var word = this.current.word;
    var count = this.requeueCount[word] || 0;
    if (grade === "unknown") {
      this.pending[word] = { row: this.current,
        dueAt: this.served + (3 + Math.floor(Math.random() * 3)) };
      this.requeueCount[word] = count + 1;
      return true;
    }
    if (grade === "fuzzy" && count === 0) {
      this.pending[word] = { row: this.current,
        dueAt: this.served + (3 + Math.floor(Math.random() * 3)) };
      this.requeueCount[word] = count + 1;
      return true;
    }
    return false;
  };
  Session.prototype.remaining = function () {
    return this.main.length + Object.keys(this.pending).length;
  };

  // ==================== 词典（分片懒加载） ====================
  var DICT_LOADED = {};
  var DICT_PENDING = {};

  function letterOf(word) {
    var c = word.charAt(0).toLowerCase();
    return (c >= "a" && c <= "z") ? c : "other";
  }

  function loadShard(letter, cb) {
    // 分片已内联/已加载则直接回调（单文件版与在线版均适用）
    if (window.DICT && window.DICT[letter]) {
      DICT_LOADED[letter] = true;
      cb && cb();
      return;
    }
    if (DICT_LOADED[letter]) { cb && cb(); return; }
    if (DICT_PENDING[letter]) { DICT_PENDING[letter].push(cb || function(){}); return; }
    DICT_PENDING[letter] = [cb || function(){}];
    var s = document.createElement("script");
    s.src = "data/dict_" + letter + ".js";
    s.onload = function () {
      DICT_LOADED[letter] = true;
      (DICT_PENDING[letter] || []).forEach(function (f) { f(); });
      DICT_PENDING[letter] = [];
    };
    s.onerror = function () {
      DICT_LOADED[letter] = true; // 该分片缺失视为空
      (DICT_PENDING[letter] || []).forEach(function (f) { f(); });
      DICT_PENDING[letter] = [];
    };
    document.head.appendChild(s);
  }

  function dictLookup(word) {
    var shard = window.DICT && window.DICT[letterOf(word)];
    return shard ? (shard[word] || null) : null;
  }

  // ==================== 收录 ====================
  function cleanInput(text) {
    var w = (text || "").trim().toLowerCase().replace(/\u2019/g, "'");
    if (!w) return null;
    if (!/^[a-z]+(['-][a-z]+)*$/.test(w)) return null;
    return w;
  }

  function collectWord(word, cb) {
    word = cleanInput(word);
    if (!word) { cb({ ok: false, reason: "invalid" }); return; }
    if (state.notebook[word]) { cb({ ok: false, reason: "duplicate", word: word }); return; }
    loadShard(letterOf(word), function () {
      var d = dictLookup(word);
      if (!d) {
        cb({ ok: false, reason: "not_found", word: word, shard: letterOf(word) });
        return;
      }
      var shard = window.DICT[letterOf(word)] || {};
      var roots = d.r || computeRoots(word, shard);
      var confusables = d.x || computeConfusables(word, shard);
      var now = new Date().toISOString().slice(0, 19).replace("T", " ");
      state.notebook[word] = {
        word: word, phonetic: d.p || "", translation: d.t || "",
        example: d.e || "", roots: roots, confusables: confusables,
        status: "NEW", repetition: 0, interval_days: 0, ef: 2.5,
        next_review: "", added_at: now, last_reviewed: "",
        total_reviews: 0, fuzzy_count: 0
      };
      save();
      cb({ ok: true, word: word, entry: state.notebook[word] });
    });
  }

  function suggestFromShard(word, shard) {
    // 简单候选：同一分片内编辑距离 <= 3 的词（最多 3 个）
    var pool = window.DICT[shard] || {};
    var cands = [];
    var w = word;
    Object.keys(pool).forEach(function (k) {
      if (cands.length >= 6) return;
      if (Math.abs(k.length - w.length) > 2) return;
      if (dlDistance(w, k, 3) <= 3) cands.push(k);
    });
    cands.sort();
    return cands.slice(0, 3).map(function (k) {
      return { word: k, trans: firstLine(pool[k].t).slice(0, 30) };
    });
  }

  function dlDistance(a, b, threshold) {
    var la = a.length, lb = b.length;
    if (Math.abs(la - lb) > threshold) return threshold + 1;
    var prev = [], i, j;
    for (j = 0; j <= lb; j++) prev[j] = j;
    for (i = 1; i <= la; i++) {
      var cur = [i];
      for (j = 1; j <= lb; j++) {
        var cost = a[i - 1] === b[j - 1] ? 0 : 1;
        cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost);
        if (i > 1 && j > 1 && a[i - 1] === b[j - 2] && a[i - 2] === b[j - 1]) {
          cur[j] = Math.min(cur[j], prev[j - 2] + 1);
        }
      }
      prev = cur;
    }
    return prev[lb];
  }

  function lcp(a, b) {
    var n = 0;
    while (n < a.length && n < b.length && a[n] === b[n]) n++;
    return n;
  }

  // ---------- 前端按需计算：同根词 / 形近词（分片内局部计算，毫秒级） ----------
  var SUFFIXES = ["ization", "isation", "ational", "ation", "ition", "ution",
    "sion", "tion", "ness", "ment", "ity", "ety", "ive", "ous", "ious", "eous",
    "ful", "less", "able", "ible", "ally", "ly", "er", "or", "ator", "etic",
    "ist", "ism", "al", "ic", "ing", "ed", "es", "s", "est", "y"];
  SUFFIXES.sort(function (a, b) { return b.length - a.length; });
  var PREFIXES = ["anti", "auto", "circum", "contra", "counter", "dis", "en",
    "em", "fore", "in", "im", "inter", "intra", "mis", "non", "over", "out",
    "post", "pre", "pro", "re", "semi", "sub", "super", "sur", "trans",
    "ultra", "un", "under", "up", "ab", "ad", "com", "con", "col", "cor",
    "de", "ex", "extra", "hyper", "hypo", "mono", "multi", "per", "poly",
    "tele", "tri", "uni", "be", "bi", "co"];

  function stemOf(w) {
    w = w.toLowerCase();
    for (var i = 0; i < SUFFIXES.length; i++) {
      var suf = SUFFIXES[i];
      if (w.length - suf.length >= 3 && w.slice(-suf.length) === suf) {
        return w.slice(0, w.length - suf.length);
      }
    }
    for (var j = 0; j < PREFIXES.length; j++) {
      var pre = PREFIXES[j];
      if (w.length - pre.length >= 4 && w.indexOf(pre) === 0) {
        return w.slice(pre.length);
      }
    }
    return null;
  }

  function computeConfusables(word, shard) {
    shard = shard || {};
    var hits = [];
    var keys = Object.keys(shard);
    for (var i = 0; i < keys.length; i++) {
      var cand = keys[i];
      if (cand === word) continue;
      if (Math.abs(cand.length - word.length) > 2) continue;
      var d = dlDistance(word, cand, 3);
      if (d <= 2) {
        hits.push({ d: d, w: cand, t: firstLine(shard[cand].t).slice(0, 40) });
      } else if (d <= 3 && word.length >= 5 && cand.length >= 5 && lcp(word, cand) >= 4) {
        hits.push({ d: d, w: cand, t: firstLine(shard[cand].t).slice(0, 40) });
      }
    }
    hits.sort(function (a, b) { return a.d - b.d || (a.w < b.w ? -1 : 1); });
    if (hits.length < 3) {
      // 不足 3 个时放宽到距离 3（重扫一次）
      for (var k = 0; k < keys.length; k++) {
        var c2 = keys[k];
        if (c2 === word || hits.some(function (h) { return h.w === c2; })) continue;
        if (Math.abs(c2.length - word.length) > 3) continue;
        var d2 = dlDistance(word, c2, 3);
        if (d2 === 3) hits.push({ d: d2, w: c2, t: firstLine(shard[c2].t).slice(0, 40) });
      }
      hits.sort(function (a, b) { return a.d - b.d || (a.w < b.w ? -1 : 1); });
    }
    return hits.slice(0, 6).map(function (h) { return { word: h.w, trans: h.t }; });
  }

  function computeRoots(word, shard) {
    shard = shard || {};
    var stem = stemOf(word);
    if (!stem) return [];
    var found = [];
    var keys = Object.keys(shard);
    for (var i = 0; i < keys.length; i++) {
      var cand = keys[i];
      if (cand === word) continue;
      var cs = stemOf(cand);
      if (cs && (cs === stem ||
          (cs.length >= 4 && (stem.indexOf(cs) === 0 || cs.indexOf(stem) === 0)))) {
        found.push(cand);
      }
    }
    found.sort(function (a, b) { return (shard[b].c || 0) - (shard[a].c || 0); });
    return found.slice(0, 8);
  }

  // ==================== 卡片渲染 ====================
  // 释义行拆分：先剥 POS 代码，再按首个空格切 [词性, 释义]；无空格整行视为释义
  function splitTrans(trans) {
    var lines = [];
    (trans || "").split("\n").forEach(function (line) {
      line = line.replace(POS_STRIP, "").trim();
      if (!line) return;
      var sp = line.indexOf(" ");
      if (sp > 0) {
        lines.push({ pos: line.slice(0, sp).trim(), meaning: line.slice(sp + 1).trim() });
      } else {
        lines.push({ pos: "", meaning: line });
      }
    });
    return lines;
  }

  // 释义 HTML：词性（灰小字）与释义分离，拉开间距
  function transHtml(trans) {
    return splitTrans(trans).map(function (l) {
      return '<div class="trans-line">' +
        (l.pos ? '<span class="trans-pos">' + esc(l.pos) + "</span>" : "") +
        '<span class="trans-meaning">' + esc(l.meaning) + "</span></div>";
    }).join("");
  }

  // 纯释义文本（拼写巩固模式：隐藏词性）
  function transText(trans) {
    return splitTrans(trans).map(function (l) { return l.meaning; }).join("\n");
  }

  // 同根词/易混淆词渲染为可点击链接（点击进入该词详细页）
  function linkify(word) {
    return word.replace(/'/g, "\\'");
  }

  function rootsHtml(roots) {
    if (!roots || !roots.length) return "暂无同根词";
    return roots.map(function (r) {
      return '<a class="root-link" href="javascript:void(0)" ' +
             'onclick="window.openWordDetail(\'' + linkify(r) + '\')">' +
             esc(r) + "</a>";
    }).join(" ");
  }

  function confsHtml(confusables) {
    if (!confusables || !confusables.length) return "暂无形近词";
    return confusables.map(function (c) {
      return '<div class="conf-item"><a class="conf-link" ' +
             'href="javascript:void(0)" onclick="window.openWordDetail(\'' +
             linkify(c.word) + '\')">' + esc(c.word) + "</a><span>" +
             esc(c.trans || "") + "</span></div>";
    }).join("");
  }

  function renderCardBody(row) {
    var html = "";
    html += '<div class="card-sec"><div class="sec-title">词义</div><div class="sec-body">' +
            transHtml(row.translation) + "</div></div>";
    html += '<div class="card-sec"><div class="sec-title">例句</div><div class="sec-body">' +
            esc(row.example || "暂无例句") + "</div></div>";
    html += '<div class="card-sec"><div class="sec-title">同根词</div><div class="sec-body">' +
            rootsHtml(row.roots) + "</div></div>";
    html += '<div class="card-sec"><div class="sec-title">易混淆</div><div class="sec-body">' +
            confsHtml(row.confusables) + "</div></div>";
    return html;
  }

  // 词典详情内容（查词弹窗与点击跳转共用）：音标/词义/例句/同根词/易混淆（均可点击跳转）
  function renderDictDetail(word, d) {
    var ph = d.p || "";
    if (ph && ph.charAt(0) !== "/") ph = "/" + ph + "/";
    var stars = d.c || 0;
    var shard = window.DICT[letterOf(word)] || {};
    var roots = d.r || computeRoots(word, shard);
    var conf = d.x || computeConfusables(word, shard);
    return '<div class="word-card detail-card">' +
      '<div class="word-front"><div class="word-word">' + esc(word) + "</div>" +
      '<div class="word-phonetic">' + esc(ph) + "</div>" +
      (stars ? '<div class="stars">' + "★".repeat(stars) + "</div>" : "") + "</div>" +
      '<div class="word-back">' +
      '<div class="card-sec"><div class="sec-title">词义</div><div class="sec-body">' +
      transHtml(d.t) + "</div></div>" +
      '<div class="card-sec"><div class="sec-title">例句</div><div class="sec-body">' +
      esc(d.e || "暂无例句") + "</div></div>" +
      '<div class="card-sec"><div class="sec-title">同根词</div><div class="sec-body">' +
      rootsHtml(roots) + "</div></div>" +
      '<div class="card-sec"><div class="sec-title">易混淆</div><div class="sec-body">' +
      confsHtml(conf) + "</div></div>" +
      "</div></div>";
  }

  function showDetail(word) {
    var row = state.notebook[word];
    if (!row) return;
    var ph = row.phonetic || "";
    if (ph && ph.charAt(0) !== "/") ph = "/" + ph + "/";
    var body = document.createElement("div");
    body.innerHTML =
      '<div class="word-card detail-card">' +
      '<div class="word-front">' +
      '<div class="word-word">' + esc(row.word) + "</div>" +
      '<div class="word-phonetic">' + esc(ph) + "</div></div>" +
      '<div class="word-back">' + renderCardBody(row) + "</div></div>";
    openModal(body);
  }

  function openModal(el) {
    $("#modalBody").innerHTML = "";
    var x = document.createElement("button");
    x.className = "modal-x";
    x.innerHTML = "&times;";
    x.setAttribute("aria-label", "关闭");
    x.onclick = closeModal;
    $("#modalBody").appendChild(x);
    $("#modalBody").appendChild(el);
    $("#modal").classList.remove("hidden");
  }
  function closeModal() { $("#modal").classList.add("hidden"); }

  // ==================== 学习流程 UI ====================
  var session = null;

  function startStudy() {
    session = new Session();
    if (!session.total) {
      alert("今日没有任务，先添加一些生词吧！");
      session = null;
      return;
    }
    $("#studyHome").classList.add("hidden");
    $("#studyCard").classList.remove("hidden");
    nextCard();
  }

  function nextCard() {
    var row = session.nextWord();
    if (!row) {
      finishStudy();
      return;
    }
    var ph = row.phonetic || "";
    if (ph && ph.charAt(0) !== "/") ph = "/" + ph + "/";
    $("#cardWord").textContent = row.word;
    $("#cardPhonetic").textContent = ph;
    $("#cardBackWord").textContent = row.word;
    $("#cardTrans").innerHTML = transHtml(row.translation);
    $("#cardExample").textContent = row.example || "暂无例句";
    $("#cardRoots").innerHTML = rootsHtml(row.roots);
    $("#cardConf").innerHTML = confsHtml(row.confusables);
    var stars = row.collins || 0;
    $("#cardStars").textContent = stars ? "★".repeat(stars) : "";
    var card = $("#wordCard");
    card.classList.remove("flipped");
    card.classList.remove("flip-in");
    void card.offsetWidth; // 重启动画
    card.classList.add("flip-in");
    $("#gradeRow").classList.add("hidden");
    var done = session.total - session.remaining();
    $("#studyProgressText").textContent = done + "/" + session.total;
    $("#studyProgressBar").style.width = (done / session.total * 100) + "%";
  }

  function reveal() {
    $("#wordCard").classList.add("flipped");
    $("#gradeRow").classList.remove("hidden");
  }

  function submitGrade(grade) {
    if (!session || !session.current) return;
    var today = todayStr();
    applyGrade(session.current.word, grade, today);
    session.submitGrade(grade);
    nextCard();
  }

  function finishStudy() {
    var r = session.results;
    var done = session.total;
    $("#studyCard").classList.add("hidden");
    $("#studyHome").classList.remove("hidden");
    session = null;
    refreshStudyHome();
    $("#taskCard").innerHTML =
      '<div class="task-num" style="font-size:26px;margin-top:10px;">本次完成 ' + done + " 词</div>" +
      '<div class="task-label" style="margin-top:8px;">认识 ' + r.know +
      " · 模糊 " + r.fuzzy + " · 不认识 " + r.unknown + "</div>";
    refreshList(); refreshStats();
  }

  function stopStudy() {
    session = null;
    $("#studyCard").classList.add("hidden");
    $("#studyHome").classList.remove("hidden");
    refreshStudyHome();
    refreshList(); refreshStats();
  }

  // ==================== 拼写巩固（看中文拼英文） ====================
  var spell = null; // {queue, idx, correct, wrong, checked}

  function todaySpellWords() {
    var today = todayStr();
    var words = [];
    state.log.forEach(function (l) {
      if ((l.at || "").slice(0, 10) === today && state.notebook[l.word]) {
        words.push(l.word);
      }
    });
    return words;
  }

  function startSpell(words) {
    var seen = {}, list = [];
    (words || []).forEach(function (w) {
      if (w && state.notebook[w] && !seen[w]) { seen[w] = 1; list.push(w); }
    });
    if (!list.length) {
      alert("暂无可用单词：先学完一批生词再来拼写巩固吧！");
      return;
    }
    spell = { queue: list, idx: 0, correct: 0, wrong: 0, checked: false };
    $("#studyHome").classList.add("hidden");
    $("#studyCard").classList.add("hidden");
    $("#spellCard").classList.remove("hidden");
    spellNext();
  }

  function spellNext() {
    var s = spell;
    if (s.idx >= s.queue.length) { spellFinish(); return; }
    var row = state.notebook[s.queue[s.idx]];
    $("#spellCn").textContent = transText(row.translation) || "暂无释义";
    var stars = row.collins || 0;
    $("#spellStars").textContent = stars ? "★".repeat(stars) : "";
    $("#spellFeedback").classList.add("hidden");
    $("#spellFeedback").className = "spell-feedback hidden";
    $("#spellHint").textContent = "";
    var inp = $("#spellInput");
    inp.value = ""; inp.classList.remove("correct", "wrong"); inp.disabled = false;
    $("#btnSpellCheck").textContent = "检查";
    $("#btnSpellCheck").className = "btn btn-primary";
    s.checked = false;
    $("#spellProgressText").textContent = s.idx + "/" + s.queue.length;
    $("#spellProgressBar").style.width = (s.idx / s.queue.length * 100) + "%";
    setTimeout(function () { inp.focus(); }, 60);
  }

  function checkSpell() {
    if (!spell) return;
    var s = spell;
    if (s.checked) {  // 已检查过 -> 推进到下一题
      s.idx += 1;
      spellNext();
      return;
    }
    var target = s.queue[s.idx];
    var answer = ($("#spellInput").value || "").trim().toLowerCase();
    var fb = $("#spellFeedback");
    fb.classList.remove("hidden");
    if (answer === target) {
      s.correct += 1;
      $("#spellInput").classList.add("correct");
      fb.className = "spell-feedback fb-ok";
      fb.innerHTML = "✓ 拼写正确！";
    } else {
      s.wrong += 1;
      $("#spellInput").classList.add("wrong");
      fb.className = "spell-feedback fb-no";
      fb.innerHTML = "✗ 再记一下<br><span class='fb-answer'>正确答案：" +
        esc(target) + "</span>";
    }
    s.checked = true;
    $("#spellInput").disabled = true;
    $("#btnSpellCheck").textContent = "下一题 →";
    $("#btnSpellCheck").className = "btn btn-primary";
  }

  function spellHint() {
    if (!spell || spell.checked) return;
    var target = spell.queue[spell.idx];
    $("#spellHint").innerHTML = "首字母提示：<b>" + esc(target.charAt(0).toUpperCase()) +
      "</b>（点击收起 <button class='hint-btn' onclick='window.__hideHint && window.__hideHint()'>×</button>）";
  }

  function spellFinish() {
    var s = spell;
    var rate = s.queue.length ? Math.round(s.correct / s.queue.length * 100) : 0;
    spell = null;
    $("#spellCard").classList.add("hidden");
    $("#studyHome").classList.remove("hidden");
    $("#taskCard").innerHTML =
      '<div class="task-num" style="font-size:26px;margin-top:10px;">拼写正确率 ' + rate + "%</div>" +
      '<div class="task-label" style="margin-top:8px;">正确 ' + s.correct +
      " · 错误 " + s.wrong + " · 共 " + s.queue.length + " 词</div>" +
      '<div class="task-detail" style="margin-top:10px;">错误词可再学一遍巩固</div>';
    refreshStudyHome(); refreshList(); refreshStats();
  }

  function spellQuit() {
    spell = null;
    $("#spellCard").classList.add("hidden");
    $("#studyHome").classList.remove("hidden");
    refreshStudyHome();
  }

  function refreshStudyHome() {
    var today = todayStr();
    var due = 0, nw = 0;
    Object.keys(state.notebook).forEach(function (w) {
      var r = state.notebook[w];
      if (r.status === "MASTERED") return;
      if (r.next_review && r.next_review <= today) due += 1;
      else if (r.status === "NEW") nw += 1;
    });
    var total = Math.min(due + nw, due + state.settings.newQuota);
    $("#taskNum").textContent = total;
    $("#taskDetail").textContent = "到期复习 " + due + " · 新词 " +
      Math.min(nw, state.settings.newQuota);
    if (total === 0) $("#btnStartStudy").textContent = "今日已完成，休息一下吧";
    else $("#btnStartStudy").textContent = "开始学习";
    // 外刊阈值提示
    var tip = document.getElementById("articleTip");
    if (!tip) {
      tip = document.createElement("div");
      tip.id = "articleTip";
      tip.className = "article-tip";
      $("#studyHome").insertBefore(tip, $("#btnSpellHome"));
    }
    var nwAll = Object.keys(state.notebook).length;
    var thr = state.settings.articleThreshold || 10;
    if (nwAll >= thr && (window.ARTICLES || []).length) {
      tip.innerHTML = '已积累 <b>' + nwAll + '</b> 个生词，去 <a href="javascript:void(0)" onclick="window.switchView(\'articles\')">外刊</a> 匹配文章巩固记忆';
      tip.style.display = "block";
    } else {
      tip.style.display = "none";
    }
  }

  // ==================== 生词本列表 ====================
  function refreshList(filter) {
    var q = (filter == null ? $("#searchBox").value : filter).trim().toLowerCase();
    var words = Object.keys(state.notebook).filter(function (w) {
      return !q || w.indexOf(q) >= 0;
    }).sort();
    $("#listCount").textContent = words.length + " 词";
    var box = $("#wordList");
    if (!words.length) {
      box.innerHTML = '<div class="word-list-empty">' +
        (q ? "没有匹配的单词" : "生词本为空，去「收录」添加吧") + "</div>";
      return;
    }
    box.innerHTML = "";
    words.forEach(function (w) {
      var r = state.notebook[w];
      var item = document.createElement("div");
      item.className = "word-item";
      item.innerHTML =
        '<span class="wi-word">' + esc(w) + "</span>" +
        '<span class="wi-trans">' + esc(firstLine(r.translation).slice(0, 26)) + "</span>" +
        '<span class="wi-status st-' + r.status + '">' + statusText(r.status) + "</span>";
      item.onclick = function () { showDetail(w); };
      box.appendChild(item);
    });
  }

  function statusText(s) {
    return { NEW: "待学", LEARNING: "学习中", REVIEWING: "复习中", MASTERED: "已掌握" }[s] || s;
  }

  // ==================== 统计 ====================
  function refreshStats() {
    var counts = { NEW: 0, LEARNING: 0, REVIEWING: 0, MASTERED: 0 };
    Object.keys(state.notebook).forEach(function (w) {
      var s = state.notebook[w].status;
      counts[s] = (counts[s] || 0) + 1;
    });
    var total = Object.keys(state.notebook).length;
    var today = todayStr();
    var todayDone = state.log.filter(function (l) {
      return (l.at || "").slice(0, 10) === today;
    }).length;
    var days = {};
    state.log.forEach(function (l) { days[(l.at || "").slice(0, 10)] = 1; });
    var streak = calcStreak(Object.keys(days));

    $("#statsGrid").innerHTML =
      statCard("acc", total, "总词数") +
      statCard("", counts.NEW, "待学") +
      statCard("", counts.LEARNING, "学习中") +
      statCard("", counts.REVIEWING, "复习中") +
      statCard("acc", counts.MASTERED, "已掌握") +
      statCard("", todayDone, "今日完成");

    var weak = Object.keys(state.notebook)
      .filter(function (w) { return state.notebook[w].fuzzy_count > 0; })
      .sort(function (a, b) {
        return state.notebook[b].fuzzy_count - state.notebook[a].fuzzy_count;
      }).slice(0, 10);
    var html = '<div class="extra-row"><span>连续学习</span><b>' + streak + " 天</b></div>";
    if (weak.length) {
      html += '<div class="extra-row" style="margin-top:6px;"><span>薄弱词 Top' +
        Math.min(weak.length, 10) + "</span></div>" + weak.map(function (w) {
          return '<div class="extra-row weak"><span>' + esc(w) +
            "</span><span>模糊 " + state.notebook[w].fuzzy_count + " 次</span></div>";
        }).join("");
    }
    $("#statsExtra").innerHTML = html;
  }

  function statCard(cls, num, label) {
    return '<div class="stat-card ' + cls + '"><div class="stat-num">' + num +
      '</div><div class="stat-label">' + label + "</div></div>";
  }

  function calcStreak(days) {
    if (!days.length) return 0;
    var set = {};
    days.forEach(function (d) { set[d] = 1; });
    var cur = new Date();
    var ds = todayStr(cur);
    if (!set[ds]) { cur.setDate(cur.getDate() - 1); ds = todayStr(cur); }
    if (!set[ds]) return 0;
    var n = 0;
    while (set[ds]) { n += 1; cur.setDate(cur.getDate() - 1); ds = todayStr(cur); }
    return n;
  }

  // ==================== 收录 UI ====================
  function renderReport(okList, dupList, missList) {
    var box = $("#addReport");
    var html = '<div class="report">';
    if (okList.length) html += '<div class="r-ok">新收录 ' + okList.length +
      "：" + esc(okList.join("、")) + "</div>";
    if (dupList.length) html += '<div class="r-dup">已在生词本 ' + dupList.length +
      "：" + esc(dupList.join("、")) + "</div>";
    if (missList.length) {
      html += '<div class="r-miss">未找到 ' + missList.length + "：</div>";
      missList.forEach(function (m) {
        html += '<div class="r-miss">' + esc(m.word) + " → 候选：" +
          esc(m.cands.map(function (c) { return c.word; }).join("、") || "无") + "</div>";
      });
    }
    html += "</div>";
    box.innerHTML = html;
    box.classList.remove("hidden");
  }

  function addOne() {
    var word = $("#addInput").value;
    if (!word.trim()) return;
    collectWord(word, function (r) {
      if (r.ok) {
        renderReport([word], [], []);
        refreshList(); refreshStats(); refreshStudyHome();
        $("#addInput").value = "";
      } else if (r.reason === "duplicate") {
        renderReport([], [word], []);
      } else if (r.reason === "invalid") {
        alert("输入无效，仅允许英文字母、连字符与撇号。");
      } else {
        loadShard(r.shard, function () {
          var cands = suggestFromShard(r.word, r.shard);
          renderReport([], [], [{ word: r.word, cands: cands }]);
        });
      }
    });
  }

  function addBulk() {
    var text = $("#bulkInput").value;
    var raw = text.split(/[\s,，;；]+/).filter(function (x) { return x; });
    if (!raw.length) return;
    var seen = {}, list = [];
    raw.forEach(function (x) {
      var w = cleanInput(x);
      if (w && !seen[w]) { seen[w] = 1; list.push(w); }
    });
    var ok = [], dup = [], miss = [];
    var i = 0;
    function next() {
      if (i >= list.length) {
        renderReport(ok, dup, miss);
        refreshList(); refreshStats(); refreshStudyHome();
        return;
      }
      var w = list[i++];
      collectWord(w, function (r) {
        if (r.ok) ok.push(w);
        else if (r.reason === "duplicate") dup.push(w);
        else {
          loadShard(r.shard, function () {
            miss.push({ word: w, cands: suggestFromShard(w, r.shard) });
            next();
          });
          return;
        }
        next();
      });
    }
    next();
  }

  // ==================== 查词典（详细释义，可选加入生词本） ====================
  function lookupWord() {
    var word = cleanInput($("#lookupInput").value);
    if (!word) { alert("请输入有效的英文单词。"); return; }
    loadShard(letterOf(word), function () {
      var d = dictLookup(word);
      if (!d) {
        var cands = suggestFromShard(word, letterOf(word));
        var html = '<div class="word-card detail-card">' +
          '<div class="word-front"><div class="word-word">' + esc(word) + "</div></div>" +
          '<div class="word-back"><div class="card-sec"><div class="sec-title">查询结果</div>' +
          '<div class="sec-body">词库（牛津高阶常用词）中未收录该词。</div></div>';
        if (cands.length) {
          html += '<div class="card-sec"><div class="sec-title">相近拼写</div><div class="sec-body">' +
            confsHtml(cands) + "</div></div>";
        }
        html += "</div></div>";
      var b1 = document.createElement("div");
      b1.innerHTML = html;
      openModal(b1);
      return;
    }
    // 详细释义：完整义项 + 例句 + 同根词 + 形近词 + 星级（均可点击跳转）
    showDictDetail(word, d);
  });
  }

  // 词典详细页弹窗（查词 / 点击混淆词、同根词跳转共用）
  function showDictDetail(word, d) {
    var inBook = !!state.notebook[word];
    var body = document.createElement("div");
    body.innerHTML = renderDictDetail(word, d);
    var addBtn = document.createElement("button");
    addBtn.className = "btn btn-primary";
    addBtn.style.width = "100%";
    addBtn.textContent = inBook ? "已在生词本中 ✓" : "加入生词本";
    addBtn.disabled = inBook;
    addBtn.onclick = function () {
      collectWord(word, function (r) {
        if (r.ok) {
          addBtn.textContent = "已加入生词本 ✓"; addBtn.disabled = true;
          refreshList(); refreshStats(); refreshStudyHome();
        } else if (r.reason === "duplicate") {
          addBtn.textContent = "已在生词本中 ✓"; addBtn.disabled = true;
        }
      });
    };
    body.appendChild(addBtn);
    openModal(body);
  }

  // 点击混淆词/同根词：打开该词的详细页（词库查不到则显示相近词）
  function openWordDetail(word) {
    word = (word || "").trim().toLowerCase();
    if (!word) return;
    loadShard(letterOf(word), function () {
      var d = dictLookup(word);
      if (d) { showDictDetail(word, d); return; }
      var cands = suggestFromShard(word, letterOf(word));
      var html = '<div class="word-card detail-card">' +
        '<div class="word-front"><div class="word-word">' + esc(word) + "</div></div>" +
        '<div class="word-back"><div class="card-sec"><div class="sec-title">查询结果</div>' +
        '<div class="sec-body">词库（牛津高阶常用词）中未收录该词。</div></div>';
      if (cands.length) {
        html += '<div class="card-sec"><div class="sec-title">相近拼写</div><div class="sec-body">' +
          confsHtml(cands) + "</div></div>";
      }
      html += "</div></div>";
      var body = document.createElement("div");
      body.innerHTML = html;
      openModal(body);
    });
  }

  // ==================== 设置 ====================
  function saveSettings() {
    var q = parseInt($("#setQuota").value, 10);
    var b = parseInt($("#setBoundary").value, 10);
    var t = parseInt($("#setArtThreshold").value, 10);
    if (isNaN(q) || q < 5 || q > 100) { alert("每日新词配额需在 5~100 之间"); return; }
    if (isNaN(b) || b < 0 || b > 23) { alert("日界时刻需在 0~23 之间"); return; }
    if (isNaN(t) || t < 5 || t > 50) { alert("外刊匹配阈值需在 5~50 之间"); return; }
    state.settings.newQuota = q;
    state.settings.dayBoundary = b;
    state.settings.articleThreshold = t;
    state.settings.readLevel = $("#setReadLevel").value;
    save();
    refreshStudyHome();
    alert("设置已保存。");
  }

  function exportData() {
    var blob = new Blob([JSON.stringify(state, null, 1)], { type: "application/json" });
    var a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "vocab-backup-" + todayStr() + ".json";
    document.body.appendChild(a);
    a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); }, 1000);
  }

  function importData(file) {
    var reader = new FileReader();
    reader.onload = function () {
      try {
        var data = JSON.parse(reader.result);
        if (!data.notebook) throw new Error("bad");
        state = data;
        save();
        alert("导入成功，共 " + Object.keys(state.notebook).length + " 词。");
        refreshAll();
      } catch (e) { alert("文件格式不正确。"); }
    };
    reader.readAsText(file);
  }

  // 导入外刊文章（JSON 数组，字段：id/title/source/level/topic/content/summary/structure/key_words/hard）
  function importArticles(file) {
    var reader = new FileReader();
    reader.onload = function () {
      try {
        var data = JSON.parse(reader.result);
        var list = Array.isArray(data) ? data : (data.articles || []);
        if (!list.length) throw new Error("empty");
        var ok = 0;
        list.forEach(function (a) {
          if (a && a.id && a.title && a.content) {
            if (!a.level || !LEVEL_ORDER[a.level]) a.level = "cet6";
            if (!a.word_count) a.word_count = a.content.split(/\s+/).length;
            a._user = true;
            ok++;
          }
        });
        state.articles = (state.articles || []).concat(list);
        save();
        alert("导入成功 " + ok + " 篇文章。");
        renderArticleHome();
      } catch (e) { alert("文章文件格式不正确（需为 JSON 数组，含 id/title/content）。"); }
    };
    reader.readAsText(file);
  }

  function resetData() {
    if (!confirm("确定清空全部生词与学习进度？此操作不可恢复（建议先导出备份）。")) return;
    state.notebook = {}; state.log = [];
    save();
    refreshAll();
    alert("已清空。");
  }

  // ==================== 导航 ====================
  function switchView(name) {
    $$(".view").forEach(function (v) { v.classList.remove("active"); });
    $("#view-" + name).classList.add("active");
    $$(".tab").forEach(function (t) {
      t.classList.toggle("active", t.getAttribute("data-view") === name);
    });
    if (name === "list") refreshList();
    if (name === "mine") { refreshStats(); loadSettingsUI(); }
    if (name === "study") refreshStudyHome();
    if (name === "articles") renderArticleHome();
  }

  window.switchView = switchView;

  function loadSettingsUI() {
    $("#setQuota").value = state.settings.newQuota || 20;
    $("#setBoundary").value = state.settings.dayBoundary || 4;
    $("#setArtThreshold").value = state.settings.articleThreshold || 10;
    $("#setReadLevel").value = state.settings.readLevel || "cet6";
  }

  function refreshAll() {
    refreshStudyHome(); refreshList(); refreshStats(); refreshStreak();
  }

  // ==================== 事件绑定 ====================
  function bind() {
    $$(".tab").forEach(function (t) {
      t.onclick = function () { switchView(t.getAttribute("data-view")); };
    });
    $("#tabFab").onclick = function () { switchView("add"); };
    $("#btnStartStudy").onclick = startStudy;
    $("#btnSpellHome").onclick = function () { startSpell(todaySpellWords()); };
    $("#btnSpellCheck").onclick = checkSpell;
    $("#btnSpellQuit").onclick = spellQuit;
    $("#spellInput").onkeydown = function (e) { if (e.key === "Enter") checkSpell(); };
    window.__hideHint = function () { $("#spellHint").textContent = ""; };
    window.openWordDetail = openWordDetail;
    $("#wordCard").onclick = reveal;
    $("#btnStopStudy").onclick = stopStudy;
    $$(".btn-grade").forEach(function (b) {
      b.onclick = function (e) { e.stopPropagation(); submitGrade(b.getAttribute("data-grade")); };
    });
    $("#searchBox").oninput = function () { refreshList(this.value); };
    $("#btnLookup").onclick = lookupWord;
    $("#lookupInput").onkeydown = function (e) { if (e.key === "Enter") lookupWord(); };
    $("#btnAdd").onclick = addOne;
    $("#addInput").onkeydown = function (e) { if (e.key === "Enter") addOne(); };
    $("#btnBulk").onclick = addBulk;
    $("#btnSaveSettings").onclick = saveSettings;
    $("#btnExportData").onclick = exportData;
    $("#btnImportData").onclick = function () { $("#fileImport").click(); };
    $("#fileImport").onchange = function () {
      if (this.files && this.files[0]) importData(this.files[0]);
      this.value = "";
    };
    $("#btnResetData").onclick = resetData;
    $("#btnImportArticles").onclick = function () { $("#fileArticles").click(); };
    $("#fileArticles").onchange = function () {
      if (this.files && this.files[0]) importArticles(this.files[0]);
      this.value = "";
    };
    // 文章正文生词高亮点击 → 弹注释
    $("#articleRoot").addEventListener("click", function (e) {
      var t = e.target;
      if (t && t.tagName === "MARK") {
        e.stopPropagation();
        showArticleKw(t.getAttribute("data-w"), t.textContent);
      }
    });
    $("#modalMask").onclick = closeModal;
  }

  // ==================== 外刊匹配引擎 ====================
  var LEVEL_META = {
    cet4: { cn: "四级", short: "CET-4" },
    cet6: { cn: "六级", short: "CET-6" },
    kaoyan: { cn: "考研", short: "Kaoyan" }
  };
  var LEVEL_ORDER = { cet4: 1, cet6: 2, kaoyan: 3 };

  function escRe(s) { return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"); }

  // 词形变体（规则还原：复数/时态/ing 等，用于匹配文章中的变形）
  function wordVariants(word) {
    var v = [word];
    if (word.length < 3) return v;
    if (word.endsWith("y")) {
      v.push(word.slice(0, -1) + "ies", word.slice(0, -1) + "ied");
    }
    if (word.endsWith("e")) {
      v.push(word.slice(0, -1) + "ing", word.slice(0, -1) + "ed");
    }
    v.push(word + "s", word + "es", word + "ed", word + "ing", word + "er", word + "est");
    if (/[bdfgklmnprt]$/.test(word)) {
      v.push(word + word.slice(-1) + "ing", word + word.slice(-1) + "ed");
    }
    return v.filter(function (x, i) { return v.indexOf(x) === i; });
  }

  function allArticles() {
    return (window.ARTICLES || []).concat(state.articles || []);
  }

  // 匹配：返回命中文章的 [{article, hits, coverage, density}]
  function matchArticles() {
    var words = Object.keys(state.notebook);
    var vs = {};
    words.forEach(function (w) { vs[w] = wordVariants(w); });
    var results = [];
    allArticles().forEach(function (a) {
      var text = " " + a.content.toLowerCase() + " ";
      var hits = [];
      words.forEach(function (w) {
        var list = vs[w];
        for (var i = 0; i < list.length; i++) {
          if (new RegExp("\\b" + escRe(list[i]) + "\\b").test(text)) {
            hits.push(w); break;
          }
        }
      });
      if (!hits.length) return;
      results.push({
        article: a, hits: hits,
        coverage: hits.length / words.length,
        density: hits.length / (a.word_count || Math.max(1, a.content.split(/\s+/).length))
      });
    });
    return results;
  }

  // 方案A：命中生词数量最多（覆盖优先）
  function planA(results) {
    return results.slice().sort(function (a, b) {
      return b.hits.length - a.hits.length || b.coverage - a.coverage;
    });
  }

  // 方案B：难度贴合用户目标等级 + 兼顾覆盖率
  function planB(results, level) {
    var target = LEVEL_ORDER[level] || 2;
    return results.slice().sort(function (a, b) {
      var da = Math.abs(LEVEL_ORDER[a.article.level] - target);
      var db = Math.abs(LEVEL_ORDER[b.article.level] - target);
      var sa = a.coverage * 100 - da * 8;
      var sb = b.coverage * 100 - db * 8;
      return sb - sa || b.hits.length - a.hits.length;
    });
  }

  // ==================== 外刊 UI ====================
  var artState = { results: null, plan: "A", level: "cet6" };

  function artBadge(level) {
    var m = LEVEL_META[level] || { cn: level };
    var cls = { cet4: "lv-cet4", cet6: "lv-cet6", kaoyan: "lv-kaoyan" }[level] || "lv-cet4";
    return '<span class="art-badge ' + cls + '">' + m.cn + "</span>";
  }

  function renderArticleHome() {
    var n = Object.keys(state.notebook).length;
    var thr = state.settings.articleThreshold || 10;
    var pct = Math.min(100, Math.round(n / thr * 100));
    var tip = n >= thr
      ? '<div class="art-tip ok">已达到 ' + thr + ' 个生词，开始匹配外刊文章吧！</div>'
      : '<div class="art-tip">还差 <b>' + (thr - n) + '</b> 个生词达到阈值（' + thr + "）</div>";
    $("#articleRoot").innerHTML =
      '<div class="art-home">' +
      '<div class="art-progress-card"><div class="art-num">' + n + "</div>" +
      '<div class="art-label">已积累生词 · 阈值 ' + thr + "</div>" +
      '<div class="bar"><div class="bar-fill" style="width:' + pct + '%"></div></div>' + tip + "</div>" +
      '<button class="btn btn-primary btn-big art-btn" onclick="window.artMatch(\'A\')">方案A · 覆盖生词最多</button>' +
      '<button class="btn btn-spell-home art-btn" onclick="window.artMatch(\'B\')">方案B · 难度贴合水平</button>' +
      '<div class="art-desc">方案A：优先匹配命中你生词最多的文章，快速见词。<br>' +
      "方案B：优先贴合你的目标等级（我的→阅读目标等级），再兼顾生词覆盖率，循序渐进。</div>" +
      "</div>";
  }

  function renderArticleList(results, plan) {
    var n = Object.keys(state.notebook).length;
    var planName = plan === "A" ? "方案A · 覆盖生词最多" : "方案B · 难度贴合" +
      (LEVEL_META[artState.level] || { cn: "" }).cn + " + 覆盖率";
    var cards = results.map(function (r, idx) {
      var a = r.article;
      var hitsHtml = r.hits.map(function (h) {
        return '<a class="art-hit" href="javascript:void(0)" onclick="event.stopPropagation();window.openWordDetail(\'' +
               h.replace(/'/g, "\\'") + '\')">' + esc(h) + "</a>";
      }).join(" ");
      var score = plan === "A"
        ? "命中 " + r.hits.length + " 个生词，覆盖 " + Math.round(r.coverage * 100) + "%，排第 " + (idx + 1)
        : "等级贴合 ±" + Math.abs(LEVEL_ORDER[a.level] - (LEVEL_ORDER[artState.level] || 2)) +
          "，覆盖 " + Math.round(r.coverage * 100) + "%，综合得分 " +
          Math.round(r.coverage * 100 - Math.abs(LEVEL_ORDER[a.level] - (LEVEL_ORDER[artState.level] || 2)) * 8);
      return '<div class="art-card" onclick="window.openArticle(\'' + a.id + '\')">' +
        '<div class="art-card-head"><div class="art-title">' + esc(a.title) + "</div>" +
        artBadge(a.level) + "</div>" +
        '<div class="art-meta">' + esc(a.source) + " · " + esc(a.topic) + "</div>" +
        '<div class="art-tags"><span class="art-badge hit">命中 ' + r.hits.length + " 词</span>" +
        '<span class="art-badge">覆盖率 ' + Math.round(r.coverage * 100) + "%</span>" +
        '<span class="art-badge">密度 ' + (r.density * 100).toFixed(1) + " 词/百词</span></div>" +
        '<div class="art-hits">' + hitsHtml + "</div>" +
        '<div class="art-score">' + score + "</div>" +
        "</div>";
    }).join("");
    $("#articleRoot").innerHTML =
      '<div class="art-list-head">' +
      '<button class="btn btn-ghost" onclick="window.artBackHome()">← 返回</button>' +
      '<span class="art-plan-name">' + planName + "</span></div>" +
      '<div class="art-sum">共匹配 ' + results.length + " 篇 · 生词 " + n + " 个</div>" +
      (results.length ? cards : '<div class="word-list-empty">当前生词未命中任何文章，先多积累一些生词吧</div>');
  }

  function renderArticleReader(a, hits) {
    var kw = a.key_words || [];
    var kwHtml = kw.length ? kw.map(function (k) {
      return '<div class="kw-item"><a class="kw-link" href="javascript:void(0)" ' +
             'onclick="event.stopPropagation();window.openWordDetail(\'' +
             linkify(k.w) + '\')"><b>' + esc(k.w) + "</b></a> <i>" + esc(k.p || "") +
        "</i> <span>" + esc(k.t || "") + '</span><div class="kw-s">' + esc(k.s || "") + "</div></div>";
    }).join("") : '<div class="art-none">暂无重点词汇注释</div>';
    var hardHtml = (a.hard || []).map(function (h, i) {
      return '<div class="hard-item"><div class="hard-no">长难句 ' + (i + 1) + "</div>" +
        '<div class="hard-s">' + esc(h.s) + "</div>" +
        '<div class="hard-t">译：' + esc(h.t) + "</div>" +
        '<div class="hard-a">析：' + esc(h.a) + "</div></div>";
    }).join("") || '<div class="art-none">暂无长难句解析</div>';
    var structHtml = (a.structure || []).map(function (s, i) {
      return '<div class="struct-item"><span class="struct-no">' + (i + 1) + "</span>" +
        "<b>" + esc(s.part) + "</b><p>" + esc(s.summary) + "</p></div>";
    }).join("") || '<div class="art-none">暂无篇章结构</div>';
    var transHtml = a.translation
      ? '<details class="art-trans"><summary>中文翻译</summary><div class="art-trans-body">' +
        esc(a.translation) + "</div></details>"
      : "";
    $("#articleRoot").innerHTML =
      '<div class="art-list-head"><button class="btn btn-ghost" onclick="window.artBackList()">← 返回列表</button></div>' +
      '<div class="art-reader">' +
      '<h2 class="art-reader-title">' + esc(a.title) + "</h2>" +
      '<div class="art-meta">' + esc(a.source) + " · " + artBadge(a.level) +
      " · " + esc(a.topic) + " · " + (a.word_count || "") + " 词" +
      (a.pubDate ? " · " + esc(a.pubDate) : "") +
      (a.link ? ' · <a class="art-src" href="' + esc(a.link) + '" target="_blank">原文</a>' : "") +
      "</div>" +
      '<div class="art-summary-box">主旨：' + esc(a.summary || "") + "</div>" +
      transHtml +
      '<div class="art-content" id="artContent">' + highlightContent(a, hits) + "</div>" +
      '<h3 class="art-sec-title">重点词汇（' + kw.length + "，点击查义）</h3>" + kwHtml +
      '<h3 class="art-sec-title">长难句解析（' + (a.hard || []).length + "）</h3>" + hardHtml +
      '<h3 class="art-sec-title">篇章结构</h3>' + structHtml +
      "</div>";
  }

  // 正文高亮：命中的生词 + 文章重点词（含变形）包 <mark>，点击弹注释/查词典
  function highlightContent(a, hits) {
    var text = a.content || "";
    var marks = [];
    var vs = [];
    var words = {};
    (hits || []).forEach(function (w) { words[w] = 1; });
    (a.key_words || []).forEach(function (k) { words[k.w] = 1; });
    Object.keys(words).forEach(function (w) {
      wordVariants(w).forEach(function (v) { vs.push({ w: w, v: v }); });
    });
    vs.sort(function (x, y) { return y.v.length - x.v.length; });
    var n = 0;
    vs.forEach(function (it) {
      var re = new RegExp("\\b(" + escRe(it.v) + ")\\b", "gi");
      text = text.replace(re, function (m) {
        marks[n] = { w: it.w, orig: m };
        return "\u0001" + n + "\u0001";
      });
      n = marks.length;
    });
    marks.forEach(function (mk, i) {
      text = text.split("\u0001" + i + "\u0001")
        .join('<mark class="art-mark" data-w="' + mk.w + '">' + esc(mk.orig) + "</mark>");
    });
    return text;
  }

  // 外刊正文/重点词点击：一律走完整词典详情（与生词本详情一致：音标/义项/例句/同根词/易混淆 + 加入生词本）
  function showArticleKw(word, orig) {
    openWordDetail(word);
  }

  function artMatch(plan) {
    var results = matchArticles();
    if (!results.length) {
      alert("当前生词未命中任何文章，先多积累一些生词吧！");
      renderArticleHome();
      return;
    }
    artState.plan = plan;
    artState.level = state.settings.readLevel || "cet6";
    var list = plan === "A" ? planA(results) : planB(results, artState.level);
    artState.results = list;
    renderArticleList(list, plan);
  }

  function artBackHome() { renderArticleHome(); }

  function artBackList() {
    if (artState.results) renderArticleList(artState.results, artState.plan);
    else renderArticleHome();
  }

  function openArticle(id) {
    var all = allArticles();
    var a = null;
    for (var i = 0; i < all.length; i++) { if (all[i].id === id) { a = all[i]; break; } }
    if (!a) return;
    var hits = [];
    if (artState.results) {
      for (var j = 0; j < artState.results.length; j++) {
        if (artState.results[j].article.id === id) { hits = artState.results[j].hits; break; }
      }
    }
    renderArticleReader(a, hits);
  }

  window.artMatch = artMatch;
  window.artBackHome = artBackHome;
  window.artBackList = artBackList;
  window.openArticle = openArticle;

  // ==================== 启动 ====================
  function refreshStreak() {
    var days = {};
    state.log.forEach(function (l) { days[(l.at || "").slice(0, 10)] = 1; });
    var streak = calcStreak(Object.keys(days));
    $("#topStreak").textContent = streak > 0 ? "已连续 " + streak + " 天" : "";
  }

  function init() {
    var now = new Date();
    var week = ["日", "一", "二", "三", "四", "五", "六"][now.getDay()];
    $("#topToday").textContent = "周" + week + " " + (now.getMonth() + 1) + "月" +
      now.getDate() + "日";
    bind();
    refreshAll();
    refreshStreak();
    // 注册 Service Worker（需 HTTPS 或 localhost；file:// 下静默跳过）
    if ("serviceWorker" in navigator && location.protocol.indexOf("http") === 0) {
      navigator.serviceWorker.register("./sw.js").catch(function () {});
    }
  }

  document.addEventListener("DOMContentLoaded", init);
})();
